import View from './view.js';
import Model from './model.js';

class ProductController {
    constructor(model, view) {
        this.model = model;
        this.view = view;

        this.view.bindToggleFilter(this.handleToggleFilter.bind(this));
        this.updateView();
    }

    handleToggleFilter() {
        this.model.toggleShowStockedOnly();
        this.updateView();
    }

    updateView() {
        const products = this.model.getFilteredProducts();
        this.view.displayProducts(products);
    }
}

const app = new ProductController(new ProductModel(), new ProductView());
