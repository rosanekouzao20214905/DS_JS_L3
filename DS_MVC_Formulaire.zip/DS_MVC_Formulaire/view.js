class ProductView {
    constructor() {
        this.app = document.getElementById('app');
        this.filterCheckbox = this.createElement('input', { type: 'checkbox', id: 'filter' });
        this.filterLabel = this.createElement('label', { for: 'filter' });
        this.filterLabel.textContent = 'Only show products in stock';
        this.productTable = this.createElement('table');
        this.productTable.innerHTML = `
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Price</th>
                </tr>
            </thead>
            <tbody></tbody>
        `;
        this.app.append(this.filterCheckbox, this.filterLabel, this.productTable);
    }

    createElement(tag, attributes = {}) {
        const element = document.createElement(tag);
        for (let key in attributes) {
            element[key] = attributes[key];
        }
        return element;
    }

    bindToggleFilter(handler) {
        this.filterCheckbox.addEventListener('change', handler);
    }

    displayProducts(products) {
        const tbody = this.productTable.querySelector('tbody');
        tbody.innerHTML = '';
        products.forEach(product => {
            const row = this.createElement('tr');
            row.innerHTML = `
                <td>${product.name}</td>
                <td>${product.price ? `$${product.price}` : ''}</td>
            `;
            tbody.appendChild(row);
        });
    }
}
